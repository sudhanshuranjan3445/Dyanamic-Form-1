<?php
$fields = $_POST['fields'] ?? [];
session_start();
$_SESSION['fields'] = $fields; // Store field choices for validation later
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dynamic Form</title>
    <style>
        /* ===== Background with animated gradient ===== */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(-45deg, #ff4e50, #fc913a, #f9d423, #30cfd0, #330867, #6a11cb, #2575fc);
            background-size: 400% 400%;
            animation: gradientBG 12s ease infinite;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* ===== Glassmorphism Form Box ===== */
        .box {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            padding: 30px;
            border-radius: 16px;
            width: 420px;
            color: #fff;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            animation: fadeIn 1.2s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .box h2 {
            margin-bottom: 20px;
            font-size: 1.6rem;
            text-align: center;
            letter-spacing: 1px;
        }

        /* ===== Input Styling ===== */
        label {
            display: block;
            margin: 12px 0 6px;
            font-weight: bold;
        }

        input[type="text"], 
        input[type="password"], 
        select {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: none;
            outline: none;
            margin-bottom: 12px;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            font-size: 1rem;
            transition: box-shadow 0.3s;
        }

        input[type="text"]:focus, 
        input[type="password"]:focus, 
        select:focus {
            box-shadow: 0 0 8px #00ffe7;
        }

        /* ===== Hobby Checkboxes ===== */
        .hobby-group input {
            margin-right: 6px;
            transform: scale(1.2);
            accent-color: #00e1ff;
            cursor: pointer;
        }
        .hobby-group label {
            display: inline-block;
            margin-right: 12px;
            font-weight: normal;
        }

        /* ===== Submit Button ===== */
        button {
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            border: none;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            color: white;
            cursor: pointer;
            background: linear-gradient(45deg, #ff6a00, #ee0979);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        button:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.4);
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Fill the Form</h2>
        <form method="post" action="form_submit.php">
            <?php
            foreach ($fields as $field) {
                switch ($field) {
                    case "name":
                        echo '<label>Name:</label><input type="text" name="name" required>';
                        break;
                    case "email":
                        echo '<label>Email:</label><input type="text" name="email" required>';
                        break;
                    case "mobile":
                        echo '<label>Mobile:</label><input type="text" name="mobile" required>';
                        break;
                    case "password":
                        echo '<label>Password:</label><input type="password" name="password" required>';
                        break;
                    case "gender":
                        echo '<label>Gender:</label>
                              <select name="gender" required>
                                  <option value="">--Select--</option>
                                  <option value="Male">Male</option>
                                  <option value="Female">Female</option>
                              </select>';
                        break;
                    case "hobby":
                        echo '<label>Hobby:</label>
                              <div class="hobby-group">
                                  <label><input type="checkbox" name="hobby[]" value="Reading"> Reading</label>
                                  <label><input type="checkbox" name="hobby[]" value="Sports"> Sports</label>
                                  <label><input type="checkbox" name="hobby[]" value="Music"> Music</label>
                              </div>';
                        break;
                }
            }
            ?>
            <button type="submit" name="submit_form">Submit</button>
        </form>
    </div>
</body>
</html>
