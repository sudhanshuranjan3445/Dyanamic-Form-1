<?php
session_start();
$fields = $_SESSION['fields'] ?? [];
$errors = [];
$data = [];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_form'])) {
    foreach ($fields as $field) {
        $value = $_POST[$field] ?? '';

        switch ($field) {
            case "name":
                if (empty($value) || !preg_match("/^[a-zA-Z ]*$/", $value)) {
                    $errors['name'] = "Invalid name (letters only).";
                } else {
                    $data['Name'] = htmlspecialchars($value);
                }
                break;

            case "email":
                if (empty($value) || !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors['email'] = "Invalid email.";
                } else {
                    $data['Email'] = htmlspecialchars($value);
                }
                break;

            case "mobile":
                if (empty($value) || !preg_match("/^[0-9]{10}$/", $value)) {
                    $errors['mobile'] = "Enter valid 10-digit mobile.";
                } else {
                    $data['Mobile'] = htmlspecialchars($value);
                }
                break;

            case "password":
                if (strlen($value) < 6) {
                    $errors['password'] = "Password must be at least 6 chars.";
                } else {
                    $data['Password'] = htmlspecialchars($value);
                }
                break;

            case "gender":
                if (empty($value)) {
                    $errors['gender'] = "Select gender.";
                } else {
                    $data['Gender'] = htmlspecialchars($value);
                }
                break;

            case "hobby":
                if (empty($_POST['hobby'])) {
                    $errors['hobby'] = "Select at least one hobby.";
                } else {
                    $data['Hobbies'] = htmlspecialchars(implode(", ", $_POST['hobby']));
                }
                break;
        }
    }

    // If valid → save + show data
    if (empty($errors)) {
        $line = implode(" | ", $data) . "\n";
        file_put_contents("submissions.txt", $line, FILE_APPEND);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form Submission</title>
    <style>
        /* ===== Background Animation ===== */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(-45deg, #ff4e50, #fc913a, #f9d423, #30cfd0, #330867, #6a11cb, #2575fc);
            background-size: 400% 400%;
            animation: gradientBG 12s ease infinite;
            color: #fff;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* ===== Glass Box ===== */
        .box {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            padding: 30px;
            border-radius: 16px;
            width: 500px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            animation: fadeIn 1.2s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2.success { color: #00ff95; }
        h2.error { color: #ff4e6a; }

        table {
            width: 100%;
            margin-top: 15px;
            border-collapse: collapse;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            text-align: left;
        }

        th {
            width: 30%;
            color: #ffe600;
        }

        ul {
            list-style: none;
            padding: 0;
            margin-top: 10px;
        }

        ul li {
            background: rgba(255, 0, 0, 0.2);
            margin: 6px 0;
            padding: 8px;
            border-radius: 6px;
        }

        a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: linear-gradient(45deg, #ff6a00, #ee0979);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        a:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(255,255,255,0.4);
        }
    </style>
</head>
<body>
    <div class="box">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_form'])) {
            if (empty($errors)) {
                echo "<h2 class='success'>✅ Form Submitted Successfully!</h2>";
                echo "<table>";
                foreach ($data as $key => $val) {
                    echo "<tr><th>$key</th><td>$val</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<h2 class='error'>⚠ Errors found:</h2>";
                echo "<ul>";
                foreach ($errors as $err) {
                    echo "<li>$err</li>";
                }
                echo "</ul>";
                echo "<a href='javascript:history.back()'>Go Back</a>";
            }
        }
        ?>
    </div>
</body>
</html>
