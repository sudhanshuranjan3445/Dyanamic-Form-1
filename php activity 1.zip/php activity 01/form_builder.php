<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dynamic Form Builder</title>
    <style>
        /* ===== Background with animated gradient ===== */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(-45deg, #ff4e50, #fc913a, #f9d423, #eaeaea, #30cfd0, #330867);
            background-size: 400% 400%;
            animation: gradientBG 12s ease infinite;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* ===== Form Box (Glassmorphism) ===== */
        .box {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            padding: 30px;
            border-radius: 16px;
            width: 400px;
            text-align: center;
            color: #fff;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            animation: fadeIn 1.2s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .box h2 {
            margin-bottom: 20px;
            font-size: 1.6rem;
            letter-spacing: 1px;
        }

        /* ===== Labels + Checkboxes ===== */
        label {
            display: flex;
            align-items: center;
            margin: 10px 0;
            font-size: 1.1rem;
            cursor: pointer;
            transition: color 0.3s ease;
        }
        label:hover {
            color: #ffeb3b;
        }

        input[type="checkbox"] {
            margin-right: 10px;
            transform: scale(1.2);
            accent-color: #00e1ff;
            cursor: pointer;
            transition: transform 0.2s;
        }
        input[type="checkbox"]:hover {
            transform: scale(1.4);
        }

        /* ===== Button ===== */
        button {
            margin-top: 15px;
            padding: 12px 25px;
            background: linear-gradient(45deg, #ff6a00, #ee0979);
            border: none;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            color: white;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        button:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.4);
        }

        /* ===== Selected Highlight ===== */
        .selected-label {
            color: #00ff95 !important;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2>Select Fields for Form</h2>
        <form method="post" action="form_display.php" id="form-builder">
            <label><input type="checkbox" name="fields[]" value="name"> Name</label>
            <label><input type="checkbox" name="fields[]" value="email"> Email</label>
            <label><input type="checkbox" name="fields[]" value="mobile"> Mobile</label>
            <label><input type="checkbox" name="fields[]" value="password"> Password</label>
            <label><input type="checkbox" name="fields[]" value="gender"> Gender (Dropdown)</label>
            <label><input type="checkbox" name="fields[]" value="hobby"> Hobby (Checkbox)</label>
            <button type="submit">Generate Form</button>
        </form>
    </div>

    <script>
        // Highlight labels when checked
        const checkboxes = document.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(cb => {
            cb.addEventListener('change', () => {
                if (cb.checked) {
                    cb.parentElement.classList.add('selected-label');
                } else {
                    cb.parentElement.classList.remove('selected-label');
                }
            });
        });
    </script>
</body>
</html>
